import React, { Component } from "react";
// PayrollForm Component
class PayrollForm extends Component {
  render() {
    return (
      <div style={{ width: "50%", margin: "auto", padding: "20px", border: "1px solid #ddd", borderRadius: "5px" }}>
        <Header />
      </div>
    );
  }
}
export default PayrollForm;
