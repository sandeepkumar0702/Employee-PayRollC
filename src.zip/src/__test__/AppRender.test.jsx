import React from 'react';
import { render, screen } from '@testing-library/react';
import PayrollForm from '../Components/PayrollForm/PayrollForm';

describe('Rendering PayrollForm', () => {
  test('renders the form title', () => {
    render(<PayrollForm />);
    expect(screen.getByText('Employee Payroll Form')).toBeInTheDocument();
  });
});
