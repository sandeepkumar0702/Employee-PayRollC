import PayrollForm from "./Components/PayrollForm/PayrollForm"

function App() {

  return (
    <div>
      <PayrollForm/>
    </div>
  )
}

export default App
